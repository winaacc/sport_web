/*
  AudioOutputSerialWAV
  Writes a mostly correct WAV file to the serial port
  
  Copyright (C) 2017  Earle F. Philhower, III

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "AudioOutputA2dp.h"

static const uint8_t wavHeaderTemplate[] PROGMEM = { // Hardcoded simple WAV header with 0xffffffff lengths all around
    0x52, 0x49, 0x46, 0x46, 0xff, 0xff, 0xff, 0xff, 0x57, 0x41, 0x56, 0x45,
    0x66, 0x6d, 0x74, 0x20, 0x10, 0x00, 0x00, 0x00, 0x01, 0x00, 0x02, 0x00, 0x22, 0x56, 0x00, 0x00, 0x88, 0x58, 0x01, 0x00, 0x04, 0x00, 0x10, 0x00,
    0x64, 0x61, 0x74, 0x61, 0xff, 0xff, 0xff, 0xff };

bool AudioOutputA2dp::begin()
{
  buff.clear();
  count = 0;
  total = 0;
  return true;
}

bool AudioOutputA2dp::ConsumeSample(int16_t sample[2])
{
  if (++count == 1024*4) {
    Serial.println("ble");
    count = 0;
    return false;
  }
  
  buff.push_back(sample[0]);

  return true;
}


bool AudioOutputA2dp::stop()
{
  SoundData *data = new OneChannelSoundData((int16_t*)buff.data(), buff.size());
  bleSource->write_data(data);
  buff.clear();
  buff.shrink_to_fit();
  count = 0;
  return true;
}
 
