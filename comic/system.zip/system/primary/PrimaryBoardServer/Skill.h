using namespace std;

class SkillConfig{
    public:
        int skillId;
        string name;
        string effect;
        int prob;
        string triggerPos;
        SkillConfig(int skillId,string name,string effect,int prob,string triggerPos){
            this->skillId = skillId;
            this->name = name;
            this->effect = effect;
            this->prob = prob;
            this->triggerPos = triggerPos;
        }
};

class Skill{
    public:
        SkillConfig* config;
        int level;

        Skill(SkillConfig* config){
            this->config = config;
            this->level = 1;
        }
};