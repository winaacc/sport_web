#include "Player.h"
#include "Task.h"

void Player::calculatedDamage(int attackValue)
{
    float value = attackValue - this->defend;
    if (value < 0)
    {
        value = (float)attackValue / (float)this->defend;
    }
    this->hp -= value;
    if (this->hp <= 0)
    {
        this->isDead = true;
    }
}

bool Player::canReceiveTask(){
  if(this->mainQuests.size() == 0){
    return true;
  }
    for(int i=0;i<this->mainQuests.size();i++){
        if(!this->mainQuests[i]->finish){
            return false;
        }
    }
    return true;
}

SingleTask* Player::getCurrentTask(){
    for(int i=0;i<this->mainQuests.size();i++){
        if(!this->mainQuests[i]->finish){
            return this->mainQuests[i];
        }
    }
    return NULL;
}

SingleTask* Player::getLastTask(){
  int len = this->mainQuests.size();
  if(len == 0){
    return NULL;
  }
  return this->mainQuests[len-1];
}

void Player::addExp(int val){
    this->exp += val;
}

void Player::addGold(int val){
    this->gold += val;
}

void Player::addItem(Item* obj){
    this->Backpack.push_back(obj);
}

void Player::addEquipment(Equipment* obj){
    this->Handbag.push_back(obj);
}

void Player::addSkill(Skill* obj){
    this->mainSkill = obj;
}