#include <iostream>
#include <map>
#include <vector>
#include "M5Atom.h"

using namespace std;

class Item;
class Equipment;
class SingleTask;
class Skill;

class Buff {
  public:
    std::string type;
    std::string content;
    int createtime;
    int unlocktime;
    int deletetime;

    Buff(string type,string content,int timestamp){
      this->type = type;
      this->content = content;
      this->createtime = timestamp;
      this->unlocktime = 0;
      this->deletetime = -1;
    }
};

class Player{
    public:
        std::string uuid;
        std::string name;
        int score;
        float hp;
        int mp;
        int attack;
        int defend;
        int gold;
        int netboardcoin;
        int roundtime;
        int misstime;
        int criticalHitRate;
        int exp;
        int level;

        std::vector<Item*> Backpack;
        std::vector<Equipment*> Handbag;
        std::vector<Equipment*> equipmentSlot;
        std::vector<Item*> wareHouse;

        std::vector<SingleTask*> mainQuests;
        std::vector<SingleTask*> dailyQuests;
        std::vector<SingleTask*> sideQuests;

        Skill* mainSkill;
        std::vector<string> clues;

        Buff* bigSkillBuff;
        Buff* collectBuff;

        Buff* passAndCatchBuff;
        Buff* recoverBuff;

        bool isDead;

        Player(string name){
            this->uuid = "";
            this->name = name;
            this->netboardcoin = 0;
            this->score = 0;
            this->hp = 100;
            this->mp = 20;
            this->gold = 100;
            this->roundtime = 24;
            this->misstime = 3;
            this->criticalHitRate = 10;
            this->exp = 0;
            this->level = 1;
            this->attack = 2;
            this->defend = 1;
            this->isDead = false;
            this->initBuffs();
        }

        Player(std::string uuid,
        std::string name,
        float hp,
        int mp,
        int attack,
        int defend,
        int gold,
        int netboardcoin,
        int roundtime,
        int misstime,
        int criticalHitRate,
        int exp,
        int level){
            this->uuid = uuid;
            this->name = name;
            this->score = 0;
            this->hp = hp;
            this->mp = mp;
            this->attack = attack;
            this->defend = defend;
            this->gold = gold;
            this->netboardcoin = 0;
            this->roundtime = roundtime;
            this->misstime = misstime;
            this->criticalHitRate = criticalHitRate;
            this->exp = 0;
            this->level = 0;
            this->isDead = false;
            this->mainSkill = NULL;
            this->initBuffs();
        }

        void initBuffs(){
          bigSkillBuff = NULL;
          passAndCatchBuff = NULL;
          collectBuff = NULL;
          recoverBuff = NULL;
        }

        int getTotalAttackValue(){
            return this->attack;
        }

        int getTotalDefendValue(){
            return this->defend;
        }

        bool canReceiveTask();

        void receiveTask(SingleTask* task){
            if(this->canReceiveTask()){
                mainQuests.push_back(task);
            }
        }

        void calculatedDamage(int attackValue);

        SingleTask* getCurrentTask();

        SingleTask* getLastTask();

        void addBigSkillBuff(string skillName,int timestamp){
            if(!this->bigSkillBuff){
              delete this->bigSkillBuff;
            }
            this->bigSkillBuff = new Buff("bigskill",skillName,timestamp);
        }

        void removeBigSkillBuff(){
          delete this->bigSkillBuff;
        }

        void addCollectBuff(string content,int timestamp){
          if(!this->collectBuff){
            delete this->collectBuff;
          }
          this->collectBuff = new Buff("collect",content,timestamp);
        }

        void removeCollectBuff(){
          delete this->collectBuff;
        }

        void addRecoverBuff(string content,int timestamp){
          if(!this->recoverBuff){
            delete this->recoverBuff;
          }
          this->recoverBuff = new Buff("recover",content,timestamp);
        }

        void removeRecoverBuff(){
          delete this->recoverBuff;
        }

        void addPassAndCatchBuff(string content,int timestamp){
          if(!this->passAndCatchBuff){
            delete this->passAndCatchBuff;
          }
          this->passAndCatchBuff = new Buff("passandcatch",content,timestamp);
          Serial.println(this->name.c_str() + String(" addPassAndCatchBuff!"));
        }

        void removePassAndCatchBuff(){
          delete this->passAndCatchBuff;
          Serial.println(this->name.c_str() + String(" removePassAndCatchBuff!"));
        }

        void addExp(int val);

        void addGold(int val);

        void addItem(Item* obj);

        void addEquipment(Equipment* obj);

        void addSkill(Skill* obj);
};