#include <iostream>
#include <vector>
using namespace std;

class Player;

enum EFFECT {
    HP,
    MP
};

class SingleItemConfig {
public:
    int itemId;
    string name;
    int gold;
    string fileName;
    string color;
    string effect;
    int useLevel;
    SingleItemConfig(int itemId,
    string name,
    int gold,
    string fileName,
    string color,
    string effect,
    int useLevel){
        this->itemId = itemId;
        this->name = name;
        this->gold = gold;
        this->fileName = fileName;
        this->color = color;
        this->effect = effect;
        this->useLevel = useLevel;
    }
};

class Item{
public:
    SingleItemConfig* config;
    Item(SingleItemConfig* config){
        this->config = config;
    }
};