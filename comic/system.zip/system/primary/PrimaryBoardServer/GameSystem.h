#include <iostream>
#include <map>
#include <vector>
#include "Monster.h"
#include "Item.h"
#include "Equipment.h"
#include "Skill.h"
#include "Task.h"
#include "Player.h"
#include "M5Atom.h"
#include <WiFi.h>

using namespace std;

enum GAMEMODE{
    EMERGENT,
    PROGRESSIVE,
    PVP
};

enum OPERATIONTYPE{
    OP_SHOOT,
    OP_COLLECTION,
    OP_PUZZLE,
    OP_TRIGGERRFIDTAG
};

enum TASKTYPE{
    TASK_SHOOT,
    TASK_ULTIMATESHOOT,
    TASK_COLLECTION,
    TASK_PUZZLE,
    TASK_TRIGGERTAG,
    TASK_FIGHT,
    TASK_BOSSFIGHT
};

enum FIGHTROUNDTYPE {
  FIGHT_ROUND_ATTACK,
  FIGHT_ROUND_DEFEND
};

extern vector<string> split(const string& s,const string& seperator);

class GameSystem{
    public:
        std::vector<Player*> m_players;
        GAMEMODE m_gamemode;
        std::map<string,IPAddress>* mp_playerIPMap;
        WiFiUDP* mp_playerUdp;
        std::string* mp_SystemMessage;

        // fight system
        Monster* m_currentMonster;
        Monster* m_boss;
        Player* m_lastAttackPlayer;
        bool m_isInFighting;
        FIGHTROUNDTYPE m_currentRoundType;
        int m_fightBeginTimestamp;
        int m_timestampOfCurrentRoundEnd;

        GameSystem(){
            this->m_gamemode = PROGRESSIVE;
            this->m_boss = NULL;
            this->m_currentMonster = NULL;
            this->m_lastAttackPlayer = NULL;
        }

        void sendSystemMessage(std::string message){
          this->mp_SystemMessage->assign(message);
        }

        void loadMonsterDatabaseFromCloud(){};
        void loadItemDatabaseFromCloud(){};
        void loadEquipmentDatabaseFromCloud(){};
        void loadTaskDatabaseFromCloud(){};
        void loadNPCDatabaseFromCloud(){};

        void loadMonsterDatabaseFromFile(){};
        void loadItemDatabaseFromFile(){};
        void loadEquipmentDatabaseFromFile(){};
        void loadTaskDatabaseFromFile(){};
        void loadNPCDatabaseFromFile(){};

        void loadPlayerDataFromRFIDCard(){};

        SingleItemConfig* getItemConfigById(int id);
        EquipmentConfig* getEquipmentConfigById(int id);
        SkillConfig* getSkillConfigById(int id);

        void computeRewards(Player* player,string rewards);

        void initScene(){};

        Player* getPlayer(string name){
            for(int i=0;i<m_players.size();i++){
                if(m_players[i]->name == name){
                    return m_players[i];
                }
            }
            return NULL;
        }

        std::string getPlayerData(string name){
          Player* player = this->getPlayer(name);
          if(!player){
            return "";
          }
          char data[100];
          sprintf(data,"exp:%d,gold:%d,level:%d",player->exp,player->gold,player->level);
          return string(data);
        }

        void addPlayer(string name);

        void removePlayer(){}

        void SendUDPToPlayer(string name, String message) {
          IPAddress ip = (*mp_playerIPMap)[name];
          mp_playerUdp->beginPacket(ip, 2000);
          mp_playerUdp->write((const uint8_t *)message.c_str(), message.length());
          mp_playerUdp->endPacket();
        }

        void initEmergentGame();
        void initProgressiveGame();
        void initPvpGame(){}

        int  getNextMainTask(string name);
        void receiveSingleTask(string name,int taskId);
        void receiveMultiplayerTask(int taskId);

        void processTaskAfterShootOperation(string name,string pos,int score);
        void processTaskOfRFIDTag(string name,string content);
        
        void processTaskAfterCollectionOperation(Player* player,string type,int num);
        void processTaskAfterPuzzleOperation(Player* player,string answer);
        void processTaskAfterTriggerRFIDTagOperation(Player* player,string tagData);

        void attackCurrentMonster(Player* player);
        void attackBoss(Player* player);

        void addBigSkillBuff(string name,string skillname,int timestamp){
            Player* p = this->getPlayer(name);
            if(p){
                p->addBigSkillBuff(skillname,timestamp);
            }
        }

        void addPassAndCatchBuff(string name,string content,int timestamp){
            Player* p = this->getPlayer(name);
            if(p){
              for(int i=0;i<this->m_players.size();i++){
                if(m_players[i] != p){
                  m_players[i]->addPassAndCatchBuff(content,timestamp);
                }
              }
            }
        }

        void addCollectBuff(string name,string content,int timestamp){
            Player* p = this->getPlayer(name);
            if(p){
                p->addCollectBuff(content,timestamp);
            }
        }

        void addRecoverBuff(string name,string content,int timestamp){
          Player* p = this->getPlayer(name);
            if(p){
                p->addRecoverBuff(content,timestamp);
            }
        }

        void terminatePassAndCatchBuff(string name){
          int now = millis();
          Player* p = this->getPlayer(name);
            if(p){
              for(int i=0;i<this->m_players.size();i++){
                if(m_players[i] != p){
                  m_players[i]->removePassAndCatchBuff();
                }
              }
            }
        }

        void taskSettlement(string playerName){
            Player* p = this->getPlayer(playerName);
            if(p){
                SingleTask* t = p->getCurrentTask();
                if(t->finish){
                    string rewards = t->config->rewards;
                    this->computeRewards(p,rewards);
                }
            }
        }

        void changeGameMode(){};
        void mainLogic(){};

        void emergentGameLogicExcute();
        void progressiveGameLogicExcute(int now);
        void pvpLogicExcute(){}
};