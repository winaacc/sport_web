#include "GameSystem.h"

std::vector<SingleItemConfig*> itemConfigDatabase = {
    new SingleItemConfig(1,"补血药",4,"item.jpeg","gray","hp:10",1),
    new SingleItemConfig(2,"补蓝药",4,"item.jpeg","gray","mp:10",1)
};

std::vector<EquipmentConfig*> equipmentConfigDatabase = {
    new EquipmentConfig(1,"木剑",12,"filename.jpg","gray","attack:2",1),
    new EquipmentConfig(2,"木剑",13,"filename.jpg","gray","attack:2",1)
};

std::vector<MonsterConfig*> monsterConfigDatabase = {
    new MonsterConfig(1,false,"树妖",5,1,1,0,"exp:10,gold:2,itemId:1,equipmentId:2,skillId:1"),
    new MonsterConfig(2,false,"狼妖",5,1,1,0,"exp:10,gold:2,itemId:1,equipmentId:2,skillId:1"),
    new MonsterConfig(3,false,"九尾狐",5,1,1,0,"exp:10,gold:2,itemId:1,equipmentId:2,skillId:1"),
    new MonsterConfig(4,false,"沙虫",5,1,1,0,"exp:10,gold:2,itemId:1,equipmentId:2,skillId:1"),
    new MonsterConfig(5,false,"索伦",5,1,1,0,"exp:10,gold:2,itemId:1,equipmentId:2,skillId:1")
};

std::vector<SingleTaskConfig*> taskConfigDatabase = {
    new SingleTaskConfig(1,TASK_TRIGGERTAG,"教学任务","欢迎来到游戏世界","游戏目标：激活球场上的乾位","qianH","exp:10,gold:2","搜集四魂之玉碎片",2),
    new SingleTaskConfig(2,TASK_TRIGGERTAG,"教学任务","开始试炼","游戏目标：选择属于自己的球架","chooseHoop","exp:10,gold:2","搜集四魂之玉碎片",10),
    new SingleTaskConfig(3,TASK_SHOOT,"投篮任务","你来到了一片空地","在乾位投中3个","qianH:3","exp:10,gold:2","搜集四魂之玉碎片",4),
    new SingleTaskConfig(4,TASK_SHOOT,"投篮任务","你来到了一片空地","在震位投中4个","zhenH:4","exp:10,gold:2","搜集四魂之玉碎片",5),
    new SingleTaskConfig(5,TASK_COLLECTION,"采集任务","你来到了一片茂密的森林","采集3个木头","tree:5","exp:10,gold:2","搜集四魂之玉碎片",6),
    new SingleTaskConfig(6,TASK_COLLECTION,"采集任务","你来到了一个花园","采集3朵紫罗兰","flower:5","exp:10,gold:2","搜集四魂之玉碎片",7),
    new SingleTaskConfig(7,TASK_PUZZLE,"解谜任务","你来到了一片空地","篮球这项运动是谁发明的","1","exp:10,gold:2","搜集四魂之玉碎片",8),
    new SingleTaskConfig(8,TASK_PUZZLE,"解谜任务","你来到了一片空地","找到宝箱的钥匙","password:340","exp:10,gold:2","搜集四魂之玉碎片",10),
    new SingleTaskConfig(9,TASK_ULTIMATESHOOT,"大招任务","你来到了一片空地","使用大招，一共命中10个","qianH:10","exp:10,gold:2","搜集四魂之玉碎片",10),
    new SingleTaskConfig(10,TASK_FIGHT,"战斗任务","你再去寻找财宝的路上遇到一伙强盗","目标：击败拦路的强盗","hp:10","exp:10,gold:2","搜集四魂之玉碎片",11),
    new SingleTaskConfig(11,TASK_BOSSFIGHT,"战斗任务","你来到强盗的老巢","目标：击败强盗头目","hp:20-30","exp:10,gold:2","搜集四魂之玉碎片",12),
    new SingleTaskConfig(12,TASK_BOSSFIGHT,"终极任务","击败哈克南，成为救世主","12分钟内击败最终BOSS哈克南，哈克南血量为99","hp:30-50-80-99","exp:10,gold:2","搜集四魂之玉碎片",0),
};

std::vector<SkillConfig*> skillConfigDatabase = {
    new SkillConfig(1,"亢龙有悔","hp:10,mp:5,cooldowntime:10",10,"qian"),
    new SkillConfig(2,"飞龙在天","hp:10,mp:5,cooldowntime:10",10,"kun"),
    new SkillConfig(3,"龙战于野","hp:10,mp:5,cooldowntime:10",10,"zhen"),
    new SkillConfig(4,"震惊百里","hp:10,mp:5,cooldowntime:10",10,""),
};

vector<string> split(const string &s, const string &seperator)
{
    vector<string> result;
    typedef string::size_type string_size;
    string_size i = 0;

    while (i != s.size()){
        int flag = 0;
        while (i != s.size() && flag == 0)
        {
            flag = 1;
            for (string_size x = 0; x < seperator.size(); ++x)
                if (s[i] == seperator[x])
                {
                    ++i;
                    flag = 0;
                    break;
                }
        }
        flag = 0;
        string_size j = i;
        while (j != s.size() && flag == 0)
        {
            for (string_size x = 0; x < seperator.size(); ++x)
                if (s[j] == seperator[x])
                {
                    flag = 1;
                    break;
                }
            if (flag == 0)
                ++j;
        }
        if (i != j){
            result.push_back(s.substr(i, j - i));
            i = j;
        }
    }
    return result;
}

void GameSystem::addPlayer(string name){
    if(this->getPlayer(name)){
        return;
    }
    Player* player = new Player(name);
    this->m_players.push_back(player);
}

void GameSystem::initEmergentGame(){
    this->m_currentMonster = new Monster(monsterConfigDatabase[0]);
}

void GameSystem::emergentGameLogicExcute(){
    int attack = this->m_currentMonster->getTotalAttackValue();
    if(this->m_lastAttackPlayer){
        this->m_lastAttackPlayer->calculatedDamage(attack);
    }
}

void GameSystem::attackCurrentMonster(Player* player){
    int attack = player->getTotalAttackValue();
    this->m_currentMonster->calculatedDamage(attack);
}

void GameSystem::attackBoss(Player* player){
    int attack = player->getTotalAttackValue();
    this->m_boss->calculatedDamage(attack);
}

int GameSystem::getNextMainTask(string name){
  Player* player = this->getPlayer(name);
  if(!player){
      return -2;
  }
  SingleTask* task = player->getLastTask();
  if(task){
    if(task->finish){
      return task->config->nextTaskId;
    }else{
      return -1;
    } 
  }else{
    return 1;
  }
}

void GameSystem::receiveSingleTask(string name,int taskId){
    Player* player = this->getPlayer(name);
    if(!player){
        return;
    }
    
    SingleTaskConfig* config = NULL;
    for(int i=0;i<taskConfigDatabase.size();i++){
        if(taskConfigDatabase[i]->taskId == taskId){
            config = taskConfigDatabase[i];
        }
    }

    SingleTask* t = new SingleTask(config);
    player->receiveTask(t);
    SendUDPToPlayer(name,String(t->config->desc.c_str()) + " " + String(t->config->target.c_str()));
    Serial.println(String(name.c_str())+" received task");

    int now = millis();
    if(t->config->type == TASK_FIGHT){
      this->m_fightBeginTimestamp = now + 10*1000;
      m_isInFighting = true;
      m_currentRoundType = FIGHT_ROUND_ATTACK;
      m_timestampOfCurrentRoundEnd = now + 10*1000 + 24*1000;
      m_currentMonster = new Monster();
    }else if(t->config->type == TASK_BOSSFIGHT){

    }
}

void GameSystem::receiveMultiplayerTask(int taskId){
    SingleTaskConfig* config = NULL;
    for(int i=0;i<taskConfigDatabase.size();i++){
        if(taskConfigDatabase[i]->taskId == taskId){
            config = taskConfigDatabase[i];
        }
    }

    SingleTask* t = new SingleTask(config);
    for(int i=0;i<this->m_players.size();i++){
        this->m_players[i]->receiveTask(t);
    }
}

void GameSystem::initProgressiveGame(){
    for(int i=0;i<monsterConfigDatabase.size();i++){
        if(monsterConfigDatabase[i]->isBoss){
            Monster* boss = new Monster(monsterConfigDatabase[i]);
            this->m_boss = boss;
            this->m_boss->setHenshinNum(3);
            this->m_boss->setActive(false);
            break;  
        }
    }
}

void GameSystem::processTaskAfterShootOperation(string name,string pos,int score){
  Player* player = this->getPlayer(name);
    if(!player){
        return;
    }
    SingleTask* t = player->getCurrentTask();
    if(!t){
      return;
    }
    if(t->config->type == TASK_SHOOT){
        string finishCondition = t->config->finishCondition;
        int delimiterIndex = finishCondition.find_first_of(':');
        string setupPos = finishCondition.substr(0,delimiterIndex);
        string shootcount = finishCondition.substr(delimiterIndex+1);
        int shootcoutnum = atoi(shootcount.c_str());
        if(pos == setupPos){
            t->process++;
            if(t->process >= shootcoutnum){
                t->finish = true;
                this->computeRewards(player,t->config->rewards);
                SendUDPToPlayer(name,String("任务完成:")+t->config->rewards.c_str());
            }else{
              SendUDPToPlayer(name,String("任务进度：")+t->process);
            }
        }
    }else if(t->config->type == TASK_FIGHT){

    }else if(t->config->type == TASK_BOSSFIGHT){

    }
}

void GameSystem::processTaskOfRFIDTag(string name,string content){
  Serial.println("processTaskOfRFIDTag:"+String(content.c_str()));
  Player* player = this->getPlayer(name);
    if(!player){
        return;
  }
  SingleTask* t = player->getCurrentTask();
  if(!t){
    //Serial.println("current task is not exist!");
    return;
  }
  Serial.println("currentTask:"+t->config->taskId);
  if(t->config->type == TASK_COLLECTION){
    this->processTaskAfterCollectionOperation(player, content, 1);
  }else if(t->config->type == TASK_TRIGGERTAG){
    this->processTaskAfterTriggerRFIDTagOperation(player, content);
  }else if(t->config->type == TASK_PUZZLE){
    this->processTaskAfterPuzzleOperation(player, content);
  }
}


void GameSystem::processTaskAfterCollectionOperation(Player* player,string type,int num){
    SingleTask* t = player->getCurrentTask();
    if(!t){
      return;
    }
    if(t->config->type == TASK_COLLECTION){
        string finishCondition = t->config->finishCondition;
        int delimiterIndex = finishCondition.find_first_of(':');
        string collectType = finishCondition.substr(0,delimiterIndex);
        string collectcount = finishCondition.substr(delimiterIndex+1);
        int collectcountnum = atoi(collectcount.c_str());
        if(type == collectType){
            t->process += num;
            if(t->process >= collectcountnum){
                t->finish = true;
                this->computeRewards(player,t->config->rewards);
                SendUDPToPlayer(player->name,String("任务完成:")+t->config->rewards.c_str());
            }else{
                SendUDPToPlayer(player->name,String("任务进度：")+t->process);
            }
        }
    }
}

void GameSystem::processTaskAfterTriggerRFIDTagOperation(Player* player,string tagData){
    SingleTask* t = player->getCurrentTask();
    if(!t){
      return;
    }
    if(t->config->type == TASK_TRIGGERTAG){
        string finishCondition = t->config->finishCondition;

        if(String(tagData.c_str()).startsWith(finishCondition.c_str())){
            t->process = 1;
            t->finish = true;
            this->computeRewards(player,t->config->rewards);
            SendUDPToPlayer(player->name,String("任务完成:")+t->config->rewards.c_str());
        }
    }
}

void GameSystem::processTaskAfterPuzzleOperation(Player* player,string answer){
    SingleTask* t = player->getCurrentTask();
    if(!t){
      return;
    }
    if(t->config->type == TASK_PUZZLE){
        string finishCondition = t->config->finishCondition;
        if(answer == finishCondition){
            t->process = 1;
            t->finish = true;
            this->computeRewards(player,t->config->rewards);
            SendUDPToPlayer(player->name,String("任务完成:")+t->config->rewards.c_str());
        }
    }
}

SingleItemConfig* GameSystem::getItemConfigById(int id){
    for(int i=0;i<itemConfigDatabase.size();i++){
        if(itemConfigDatabase[i]->itemId == id){
            return itemConfigDatabase[i];
        }
    }
    return NULL;
}

EquipmentConfig* GameSystem::getEquipmentConfigById(int id){
    for(int i=0;i<equipmentConfigDatabase.size();i++){
        if(equipmentConfigDatabase[i]->equipmentId == id){
            return equipmentConfigDatabase[i];
        }
    }
    return NULL;
}

SkillConfig* GameSystem::getSkillConfigById(int id){
    for(int i=0;i<skillConfigDatabase.size();i++){
        if(skillConfigDatabase[i]->skillId == id){
            return skillConfigDatabase[i];
        }
    }
    return NULL;
}

void GameSystem::computeRewards(Player* player,string rewards){
    vector<string> arr = split(rewards,",");
    for(vector<string>::size_type i = 0; i != arr.size(); ++i){
        string reward = arr[i];
        vector<string> rewardArr = split(reward,":");
        string type = rewardArr[0];
        int val = atoi(rewardArr[1].c_str());
        if(type == "exp"){
            player->addExp(val);
        }else if(type == "gold"){
            player->addGold(val);
        }else if(type == "itemId"){
            SingleItemConfig* config = this->getItemConfigById(val);
            Item* item = new Item(config);
            player->addItem(item);
        }else if(type == "equipmentId"){
            EquipmentConfig* config = this->getEquipmentConfigById(val);
            Equipment* equipment = new Equipment(config);
            player->addEquipment(equipment);
        }else if(type == "skillId"){
            SkillConfig* config = this->getSkillConfigById(val);
            Skill* skill = new Skill(config);
            player->addSkill(skill);
        }
    }
}

void GameSystem::progressiveGameLogicExcute(int now){

  if(this->m_boss){
    if(this->m_boss->active){
        int attack = this->m_boss->getTotalAttackValue();
        if(this->m_lastAttackPlayer){
            this->m_lastAttackPlayer->calculatedDamage(attack);
        }
    }
  }

}





