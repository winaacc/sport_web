#include <iostream>
#include <vector>
using namespace std;

class Player;

class EquipmentConfig{
    public:
        int equipmentId;
        string name;
        int gold;
        string fileName;
        string color;
        string effect;
        int useLevel;
    EquipmentConfig(int equipmentId,
        string name,
        int gold,
        string fileName,
        string color,
        string effect,
        int useLevel){
            this->equipmentId = equipmentId;
            this->name = name;
            this->gold = gold;
            this->fileName = fileName;
            this->color = color;
            this->effect = effect;
            this->useLevel = useLevel;
        } 
};

class Equipment {
public:
    EquipmentConfig* config;
    Equipment(EquipmentConfig* config){
        this->config = config;
    }
};