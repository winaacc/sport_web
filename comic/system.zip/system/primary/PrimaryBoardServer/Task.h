
using namespace std;

class SingleTaskConfig{
    public:
        int taskId;
        int type;
        string title;
        string desc;
        string target;
        string finishCondition;
        string rewards;
        string clues;
        int nextTaskId;

        SingleTaskConfig(
            int taskId,
            int type,
            string title,
            string desc,
            string target,
            string finishCondition,
            string rewards,
            string clues,
            int nextTaskId
        ){
            this->taskId = taskId;
            this->type = type;
            this->title = title;
            this->desc = desc;
            this->target = target;
            this->finishCondition = finishCondition;
            this->rewards = rewards;
            this->clues = clues;
            this->nextTaskId = nextTaskId;
        }
};

class SingleTask{
    public:
        SingleTaskConfig* config;
        int process;
        string data;
        bool finish;

        SingleTask(SingleTaskConfig* config){
            this->config = config;
            this->process = 0;
            this->data = "";
            this->finish = false;
        }
};