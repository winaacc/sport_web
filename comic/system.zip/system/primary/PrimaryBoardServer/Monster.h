using namespace std;

class MonsterConfig{
    public:
        bool isBoss;
        int monsterId;
        std::string name;
        int hp;
        int attack;
        int defend;
        int criticalHitRate;
        string rewards;

        MonsterConfig(int monsterId,
        bool isBoss,
        std::string name,
        int hp,
        int attack,
        int defend,
        int criticalHitRate,
        string rewards){
            this->isBoss = isBoss;
            this->monsterId = monsterId;
            this->name = name;
            this->hp = hp;
            this->attack = attack;
            this->defend = defend;
            this->criticalHitRate = criticalHitRate;
            this->rewards = rewards;
        }
};

class Monster{
    public:
        MonsterConfig* config;
        int hp;
        int attack;
        int defend;
        bool isDead;
        int henshinNum;
        bool active;

        Monster(){
          this->hp = 10;
          this->defend = 1;
          this->attack = 1;
          this->isDead = false;
          this->active = true;
        }

        Monster(MonsterConfig* config){
            this->config = config;
            this->hp = config->hp;
            this->defend = config->defend;
            this->attack = config->attack;
            this->isDead = false;
            this->active = true;
        }

        void setActive(bool active){
            this->active = active;
        }

        void setHenshinNum(int num){
            this->henshinNum = num;
        }

        int getTotalAttackValue(){
            return this->attack;
        }

        void calculatedDamage(int attackValue){
            float value = attackValue - this->defend;
            if(value < 0){
                value = (float)attackValue / (float)this->defend;
            }
            this->hp -= value;
            if(this->hp <= 0){
                this->isDead = true;
            }
        }
};